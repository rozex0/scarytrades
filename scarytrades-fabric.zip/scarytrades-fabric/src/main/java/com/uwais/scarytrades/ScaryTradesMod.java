package com.uwais.scarytrades;

import com.uwais.scarytrades.entity.ModEntities;
import net.fabricmc.api.ModInitializer;

public class ScaryTradesMod implements ModInitializer {
    public static final String MODID = "scarytrades";

    @Override
    public void onInitialize() {
        ModEntities.register();
    }
}
