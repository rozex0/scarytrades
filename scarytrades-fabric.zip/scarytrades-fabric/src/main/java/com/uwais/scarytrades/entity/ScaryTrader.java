package com.uwais.scarytrades.entity;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.level.Level;

public class ScaryTrader extends Villager {

    public ScaryTrader(EntityType<? extends Villager> type, Level level) {
        super(type, level);
        this.setNoAi(true);
        this.setPersistenceRequired();
        this.setInvulnerable(true);
    }

    // NOTE: items marked "CHECK" were recovered from obfuscated field names in
    // the original Forge jar and are best guesses. Change them here if a trade
    // pays/gives the wrong item.
    @Override
    protected void updateTrades() {
        this.getOffers().clear();
        String id = BuiltInRegistries.ENTITY_TYPE.getKey(this.getType()).getPath();
        switch (id) {
            case "kill_wish" -> {
                offer(Items.IRON_INGOT, 2, "infinity_chestplate", 1, Items.DIAMOND_CHESTPLATE);
                offer(Items.IRON_INGOT, 1, "infinity_totem", 1, Items.TOTEM_OF_UNDYING);
                offer(Items.IRON_INGOT, 1, "infinity_trident", 1, Items.TRIDENT);
                bulk(Items.IRON_INGOT, Items.TNT); // CHECK
            }
            case "entity_303" -> {
                Item pay = Items.GOLD_INGOT; // CHECK
                offer(pay, 1, "infinity_leggings", 1, Items.DIAMOND_LEGGINGS, "infinity_pants");
                offer(pay, 1, "infinity_bow", 1, Items.BOW);
                offer(pay, 1, "infinity_block", 64, Items.DIAMOND_BLOCK); // CHECK fallback
            }
            case "null" -> {
                Item pay = Items.NETHERITE_INGOT; // CHECK
                offer(pay, 1, "infinity_boots", 1, Items.DIAMOND_BOOTS);
                offer(pay, 1, "infinity_axe", 1, Items.DIAMOND_AXE);
            }
            case "bloody_notch" -> {
                Item pay = Items.REDSTONE; // CHECK
                offer(pay, 1, "ultimate_stew", 64, Items.RABBIT_STEW); // CHECK fallback
                offer(pay, 1, "infinity_pickaxe", 1, Items.DIAMOND_PICKAXE);
            }
            case "scary_villager" -> {
                offer(Items.DIAMOND, 1, "infinity_helmet", 1, Items.DIAMOND_HELMET);
                bulk(Items.DIAMOND, Items.GOLDEN_APPLE); // CHECK
                offer(Items.DIAMOND, 1, "infinity_sword", 1, Items.DIAMOND_SWORD);
            }
            default -> { }
        }
    }

    private void bulk(Item payment, Item reward) {
        this.getOffers().add(new MerchantOffer(new ItemStack(payment), new ItemStack(reward, 64), 999999, 0, 0.0F));
    }

    private void offer(Item payment, int paymentCount, String avaritiaId, int rewardCount, Item fallback, String... aliases) {
        Item reward = lookupAvaritia(avaritiaId, aliases);
        if (reward == Items.AIR) reward = fallback;
        this.getOffers().add(new MerchantOffer(new ItemStack(payment, paymentCount), new ItemStack(reward, rewardCount), 999999, 0, 0.0F));
    }

    private static Item lookupAvaritia(String id, String... aliases) {
        Item item = BuiltInRegistries.ITEM.get(new ResourceLocation("avaritia", id));
        if (item != Items.AIR) return item;
        for (String alias : aliases) {
            item = BuiltInRegistries.ITEM.get(new ResourceLocation("avaritia", alias));
            if (item != Items.AIR) return item;
        }
        return Items.AIR;
    }

    @Override
    public Component getTypeName() {
        return Component.translatable("entity.scarytrades." + BuiltInRegistries.ENTITY_TYPE.getKey(this.getType()).getPath());
    }
}
