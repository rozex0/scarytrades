package com.uwais.scarytrades.entity;

import com.uwais.scarytrades.ScaryTradesMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;

import java.util.ArrayList;
import java.util.List;

public class ModEntities {
    public static EntityType<ScaryTrader> BLOODY_NOTCH, SCARY_VILLAGER, NULL, ENTITY_303, KILL_WISH;

    private static final List<Item> EGGS = new ArrayList<>();

    private static EntityType<ScaryTrader> trader(String name) {
        EntityType<ScaryTrader> t = EntityType.Builder.<ScaryTrader>of(ScaryTrader::new, MobCategory.MISC)
                .sized(0.6F, 1.95F).clientTrackingRange(10).build(name);
        return Registry.register(BuiltInRegistries.ENTITY_TYPE, new ResourceLocation(ScaryTradesMod.MODID, name), t);
    }

    private static void egg(String name, EntityType<? extends Mob> type, int bg, int spots) {
        Item egg = new SpawnEggItem(type, bg, spots, new Item.Properties());
        Registry.register(BuiltInRegistries.ITEM, new ResourceLocation(ScaryTradesMod.MODID, name + "_spawn_egg"), egg);
        EGGS.add(egg);
    }

    public static void register() {
        BLOODY_NOTCH = trader("bloody_notch");
        SCARY_VILLAGER = trader("scary_villager");
        NULL = trader("null");
        ENTITY_303 = trader("entity_303");
        KILL_WISH = trader("kill_wish");

        for (EntityType<ScaryTrader> t : List.of(BLOODY_NOTCH, SCARY_VILLAGER, NULL, ENTITY_303, KILL_WISH)) {
            FabricDefaultAttributeRegistry.register(t, Mob.createMobAttributes()
                    .add(Attributes.MAX_HEALTH, 20.0).add(Attributes.MOVEMENT_SPEED, 0.5));
        }

        egg("bloody_notch", BLOODY_NOTCH, 3477520, 14680064);
        egg("scary_villager", SCARY_VILLAGER, 5592405, 11141120);
        egg("null", NULL, 328965, 16777215);
        egg("entity_303", ENTITY_303, 7798784, 15658734);
        egg("kill_wish", KILL_WISH, 2228224, 11149858);

        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.SPAWN_EGGS).register(entries -> EGGS.forEach(entries::accept));
    }
}
