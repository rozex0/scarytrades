package com.uwais.scarytrades;

import com.uwais.scarytrades.entity.ModEntities;
import com.uwais.scarytrades.entity.ScaryTrader;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;

public class ScaryTradesClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.BLOODY_NOTCH, ScaryHumanoidRenderer::new);
        EntityRendererRegistry.register(ModEntities.SCARY_VILLAGER, ScaryHumanoidRenderer::new);
        EntityRendererRegistry.register(ModEntities.NULL, ScaryHumanoidRenderer::new);
        EntityRendererRegistry.register(ModEntities.ENTITY_303, ScaryHumanoidRenderer::new);
        EntityRendererRegistry.register(ModEntities.KILL_WISH, ScaryHumanoidRenderer::new);
    }

    public static class ScaryHumanoidRenderer extends MobRenderer<ScaryTrader, HumanoidModel<ScaryTrader>> {
        public ScaryHumanoidRenderer(EntityRendererProvider.Context ctx) {
            super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5F);
        }

        @Override
        public ResourceLocation getTextureLocation(ScaryTrader entity) {
            String name = BuiltInRegistries.ENTITY_TYPE.getKey(entity.getType()).getPath();
            return new ResourceLocation(ScaryTradesMod.MODID, "textures/entity/" + name + ".png");
        }
    }
}
