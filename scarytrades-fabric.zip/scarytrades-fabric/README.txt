Scary Entities (Avaritia traders) - Fabric 1.20.1 port (source, untested)
Build: push this folder to a GitHub repo -> Actions tab -> "build" -> download artifact
"scarytrades-fabric-jar". Needs Fabric Loader 0.17.2+, Fabric API 0.92.2+1.20.1, Re-Avaritia (optional).
Items marked CHECK in ScaryTrader.java are best guesses.
